let laki = 0;
let perempuan = 0;

const chart = new Chart(
    document.getElementById("grafikPendaftar"), {
        type: 'bar',
        data: {
            labels: ['Laki-laki', 'Perempuan'],
            datasets: [{
                label: 'Jumlah Pendaftar',
                data: [0, 0]
            }]
        }
    }
);

function validasiForm() {
    let nama = document.getElementById("nama").value;
    let email = document.getElementById("email").value;
    let hp = document.getElementById("hp").value;
    let tglLahir = document.getElementById("tglLahir").value;
    let password = document.getElementById("password").value;
    let jk = document.getElementById("jk").value;

    let dataWajib = [nama, email, hp, tglLahir, password, jk];

    // LOOP cek data kosong
    for (let i = 0; i < dataWajib.length; i++) {
        if (dataWajib[i] === "") {
            alert("Semua data wajib diisi!");
            return false;
        }
    }

    // Validasi nomor HP (angka)
    if (isNaN(hp)) {
        alert("Nomor HP harus berupa angka");
        return false;
    }

    // Validasi password
    if (password.length < 6) {
        alert("Password minimal 6 karakter");
        return false;
    }

    // Grafik
    if (jk === "Laki-laki") {
        laki++;
    } else {
        perempuan++;
    }

    chart.data.datasets[0].data = [laki, perempuan];
    chart.update();

    document.getElementById("successMsg").style.display = "block";
    document.getElementById("grafikContainer").style.display = "block";

    // PLAY AUDIO SAAT DAFTAR
    const audio = document.getElementById("soundDaftar");
    audio.currentTime = 0;
    audio.play();

    return false;
}
